#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <stdbool.h>

// int **matmul product

// read in matrix a
// declare matrix a and matmul product
// declare matrix b

    // mr worldwide variables lol get it global variables. okay
    int** matrix_b;
	int** product;
    unsigned int l_l;
	unsigned int l_m;
    unsigned int l_n;
    unsigned int hold;

int** matMul (
    unsigned int l,
    unsigned int m,
    unsigned int n,
    int** matrix_a,
    int** matrix_b,
    int** matMulProduct
) {

    // printf("l=%d\n", l);
    // printf("m=%d\n", m);
    // printf("n=%d\n", n);

    for ( unsigned int i=0; i<l; i++ ) {
        // printf("i=%d\n", i);
        for ( unsigned int k=0; k<n; k++ ) {
            // printf("k=%d\n", k);
            matMulProduct[i][k] = 0;
            for ( unsigned int j=0; j<m; j++ ) {
                matMulProduct[i][k] += matrix_a[i][j] * matrix_b[j][k];
            }
        }
    }

// taken from matMul.c
    for (int i = 0; i < l; i++) {
        free(matrix_a[i]);
    }
    free(matrix_a);

    for (int j = 0; j < m; j++) {
        free(matrix_b[j]);
    }
    free(matrix_b);

	
    return matMulProduct;

}

unsigned int cost (
    unsigned int matrixCount,
    unsigned int* rowSizes,
    unsigned int* colSizes
) {
    if ( matrixCount==1 ) { // Base case.
        return 0; // No multplication to be done.
    } else {

        unsigned int numPossibleSplits = matrixCount-1; // Think: if there are two matrices to multiply, there is one way to split.
        // AB: (A)(B)
        // ABC: (A)(BC) and (AB)(C)

        unsigned int costs[numPossibleSplits];
        for ( unsigned int split=0; split<numPossibleSplits; split++ ) {

            unsigned int l = rowSizes[0];
            assert ( colSizes[split] == rowSizes[split+1] );
            unsigned int m = colSizes[split];
            unsigned int n = colSizes[matrixCount-1];

            costs[split] =
                cost( split+1, rowSizes, colSizes ) + // cost of left subchain
                l * m * n + // cost of multiplying the two chains
                cost( matrixCount-split-1, rowSizes+split+1, colSizes+split+1 ); // cost of right subchain
        }

        unsigned int minCost = costs[0];
        for ( unsigned int split=1; split<numPossibleSplits; split++ ) {
            if ( costs[split]<minCost ) {
                minCost = costs[split];
            }
        }

        return minCost;
    }
}



int main(int argc, char* argv[]) {

    unsigned int matrixCount;
    unsigned int* rowSizes;
    unsigned int* colSizes;

    FILE* fp = fopen(argv[1], "r");
    if (!fp) {
        perror("fopen failed");
        exit(EXIT_FAILURE);
    }

    if (!fscanf(fp, "%d\n", &matrixCount)) {
        perror("reading the number of matrices failed");
        exit(EXIT_FAILURE);
    }

		// unsigned int**totalMatrices = malloc(matrixCount*sizeof(int*));	//3d matrices where everything lives yay

	// store A B C D in separate variables
	// how do i read in the info for each matrix...

	// getting matrix a
	/*
	   FILE* matrix_a_fp = fopen(argv[1], "r");
	   if (!matrix_a_fp) {
	       perror("fopen failed");
	       return EXIT_FAILURE;
	   }
	*/

    rowSizes = calloc( matrixCount, sizeof(int) );
    colSizes = calloc( matrixCount, sizeof(int) );
    rowSizes[0] = l_l;
	colSizes[0] = l_m;

	if(!fscanf(fp, "%d %d", &l_l, &l_m)) {
		perror("reading row A failed");
		exit(EXIT_FAILURE);
	}

// taken from matMul.c	
	int** matrix_a = calloc(l_l, sizeof(int*) );
    for ( unsigned int i=0; i<l_l; i++ ) 
	{
        matrix_a[i] = calloc(l_m, sizeof(int) );
        for ( unsigned int j=0; j<l_m; j++ ) 
		{
            int a_val;
            if (!fscanf(fp, "%d", &a_val)) {
                perror("reading elements of A failed");
                exit(EXIT_FAILURE);
            }
            matrix_a[i][j] = a_val;
        }
    }

	rowSizes[0] = l_l;
	colSizes[0] = l_m;

    for (unsigned int matIndex=1; matIndex<matrixCount; matIndex++) {

        // unsigned int rows, cols;
        // if (!fscanf(fp, "%d %d\n", &rows, &cols)) {
        //     perror("reading the dimensions of matrix failed");
        //     exit(EXIT_FAILURE);
        // }
        // rowSizes[matIndex] = rows;
        // colSizes[matIndex] = cols;

		if(!fscanf(fp, "%d %d\n", &hold, &l_n)) {
			perror("reading the dimensions of matrix B failed");
			exit(EXIT_FAILURE);
		}

        rowSizes[matIndex] = hold;
		colSizes[matIndex] = l_n;

		assert(hold = l_m);

// taken from matMul.c
		matrix_b = calloc( l_m, sizeof(int*) );
        for ( unsigned int j=0; j<l_m; j++ ) {
            matrix_b[j] = calloc( l_n, sizeof(int) );
            for ( unsigned int k=0; k<l_n; k++ ) {
                int b_val;
                if (!fscanf(fp, "%d", &b_val)) {
                    perror("reading the elements of matrix B failed");
                    exit(EXIT_FAILURE);
                }
                matrix_b[j][k] = b_val;
            }
        }

        // allocating memory for delcared matMulProduct -- taken from matMul.c
        product = calloc( l_l, sizeof(int*) );
        for ( unsigned int n=0; n<l_l; n++ ) {
            product[n] = calloc( l_n, sizeof(int) );
        }

    // using matMul function with all read inouts
    matrix_a = matMul(l_l, l_m, l_n, matrix_a, matrix_b, product);
        
    // this is weird but it works so i dont want to touch it
        for(unsigned int i = 0; i < matIndex; i++) {
		l_m = l_m;
		l_m = l_n;
		l_n = l_n;
		}

    }

    printf("%d\n", cost(matrixCount, rowSizes, colSizes) );

// thank you to the cave i was so stupid in printing all this out
        for(int i = 0; i < l_l; i++){
		for(int n = 0; n < l_m; n++) {
			printf("%d ", matrix_a[i][n]);
		}
		printf("\n");
	}

    free(colSizes);
    free(rowSizes);
    fclose(fp);

    exit(EXIT_SUCCESS);
}