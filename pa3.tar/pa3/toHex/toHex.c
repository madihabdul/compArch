#include <stdlib.h>
#include <stdio.h>

int main(int argc, char *argv[])
{

    FILE *fp = fopen(argv[1], "r");
    if (!fp)
    {
        perror("fopen failed");
        return 0;
    }

    // first, read the number
    signed int input;
    fscanf(fp, "%d", &input);
    char reversePrint[4];
    //size_t* prevState = calloc(sizeof(signed int)*8, sizeof(size_t));
    int tempVal = 0;
    int counter=0;
    // print bits; you will see this kind of for loop often in this assignment
    for (int bit = 0; bit< 16; bit++)
    {

        size_t bit_val = ((1<<1)-1) & input>>bit*1; // shift and mask
        int character = bit_val ? 1 : 0;
        if(bit%4==0)
        {
            tempVal+=character;
        }
        else if(bit%4==1)
        {
            tempVal +=character*2;
        }
        else if(bit%4==2)
        {
            tempVal += character*4;
        }
        else if(bit%4==3)
        {
            tempVal += character*8;
        }
        if (bit % 4 == 3)
        {
            if (tempVal < 10)
            {
                //printf("%d", tempVal);
                reversePrint[counter]=tempVal+48;
                tempVal=0;
                counter++;
            }
            else
            {
                if (tempVal == 10)
                {
                    //printf("A");
                    reversePrint[counter]='A';
                }
                if (tempVal == 11)
                {
                    //printf("B");
                                        reversePrint[counter]='B';

                }
                if (tempVal == 12)
                {
                    //printf("C");
                                        reversePrint[counter]='C';

                }
                if (tempVal == 13)
                {
                    //printf("D");
                                        reversePrint[counter]='D';

                }
                if (tempVal == 14)
                {
                    //printf("E");
                                        reversePrint[counter]='E';

                }
                if (tempVal == 15)
                {
                    //printf("F");
                                        reversePrint[counter]='F';

                }
                tempVal=0;
                counter++;
            }
        }
        // printf("%c",character);
        // prevState[31-bit] = bit_val; // prevState[31-bit] = bit_val;
    }
    for(int i=3; i >= 0; i-- ) {
        printf("%c", reversePrint[i]);
    }
    // splitting up binary string to 4
    // for(int bit = 16; bit<32; bit+=4) {
    //     // convert bit to decimal

    //     int tempVal;

    //     // getting each of the exponent place for the binary to hex converstion
    //     tempVal = prevState[bit+3]*8 +
    //               prevState[bit+2]*4 +
    //               prevState[bit+1]*2 +
    //               prevState[bit] *1;

    // }

    // free(prevState);
    // printf("\n");

    return EXIT_SUCCESS;
}
